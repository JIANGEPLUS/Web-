

#### 

# JavaScript高级

## 面向对象

### 面向对象介绍

![image-20220924170059918](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220924170059918.png)

![image-20220924170151324](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220924170151324.png)

![image-20220924170247217](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220924170247217.png)

#### 面向对象和面向过程的对比

![image-20220924170447773](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220924170447773.png)

### ES6中的类和对象

![image-20220924170836277](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220924170836277.png)

![image-20220924171006471](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220924171006471.png)

![image-20220924171055946](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220924171055946.png)

#### 类的定义

![image-20220925123902260](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220925123902260.png)

**class后面不需要（），使用构造函数constructor（）生成属性，方法不需要function声明，方法之间不需要逗号分割**

#### 继承

![image-20220925124139737](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220925124139737.png)

![image-20220925130009732](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220925130009732.png)

**super（）调用父类的中构造函数**

![image-20220925130914507](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220925130914507.png)

![image-20220925131039715](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220925131039715.png)

super指定使用父类的函数，不然默认为子类函数





![image-20220925134205474](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220925134205474.png)

super要放在子类this之前

![image-20220925134508210](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220925134508210.png)

#### this指向问题

**constructor里面的this指向类的实例，而类的方法里面的this指向调用它的。**

**可以定义一个全局变量去装this，来让类的方法稳定调用类的实例**

### 面向对象案例tab栏

#### 添加功能

![image-20220925222356089](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220925222356089.png)

### 构造函数和原型

#### 构造函数

![image-20220926225012629](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926225012629.png)

![image-20220926225027599](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926225027599.png)

![image-20220926225044320](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926225044320.png)

![image-20220926225107774](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926225107774.png)

**构造函数问题：构造函数方法很好用，但是存在浪费内存的问题。**

构造函数通过原型分配的函数是所有对象所**共享的**。

#### 构造函数原型对象

![image-20220926225224848](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926225224848.png)

![image-20220926225257384](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926225257384.png)

![image-20220926225311749](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926225311749.png)

#### **构造函数、实例、原型对象三者之间的关系**

![image-20220926225349176](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926225349176.png)

#### 原型链

![image-20220926225419248](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926225419248.png)

####  **JavaScript** **的成员查找机制****(规则)**

![image-20220926225432195](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926225432195.png)

#### 原型对象this指向

构造函数中的this 指向我们实例对象.

原型对象里面放的是方法, 这个方法里面的this 指向的是 这个方法的调用者, 也就是这个实例对象.

#### 扩展内置对象

可以通过原型对象，对原来的内置对象进行扩展自定义的方法。比如给数组增加自定义求偶数和的功能。

**注意：数组和字符串内置对象不能给原型对象覆盖操作 Array.prototype = {} ，只能是 Array.prototype.xxx = function(){} 的方式。**

### 继承

![image-20220926225811679](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926225811679.png)

![image-20220926225838174](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926225838174.png)

#### 借用原型对象继承父类型方法

![image-20220926225917462](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926225917462.png)

### ES5新增方法

#### 数组方法

**forEach里面的return不会终止遍历**

**some找到元素会终止迭代**

**只找一个元素时，some比forEach效率更高**

![image-20220926194155418](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926194155418.png)

![image-20220926200108482](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926200108482.png)

![image-20220926200638227](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926200638227.png)

![image-20220926205910024](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926205910024.png)

#### 字符串方法

![image-20220926230043626](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926230043626.png)

#### 对象方法

![image-20220926230121196](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926230121196.png)

![image-20220926230137278](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926230137278.png)

![image-20220926230147080](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220926230147080.png)

**对象定义时本身有的属性不会按defineProperty的默认，用defineProperty生成新的属性才会生成对应默认值**

## 函数进阶

### 函数的定义和调用

![image-20220927095258938](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927095258938.png)

```javascript
<script>
        // 函数的调用方式

        // 1. 普通函数
        function fn() {
            console.log('人生的巅峰');

        }
        // fn();   fn.call()
        // 2. 对象的方法
        var o = {
            sayHi: function() {
                console.log('人生的巅峰');

            }
        }
        o.sayHi();
        // 3. 构造函数
        function Star() {};
        new Star();
        // 4. 绑定事件函数
        // btn.onclick = function() {};   // 点击了按钮就可以调用这个函数
        // 5. 定时器函数
        // setInterval(function() {}, 1000);  这个函数是定时器自动1秒钟调用一次
        // 6. 立即执行函数
        (function() {
            console.log('人生的巅峰');
        })();
        // 立即执行函数是自动调用
    </script>

```

### this的指向问题

![image-20220927100347184](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927100347184.png)



#### 改变this的指向

![image-20220927102755157](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927102755157.png)

**call（）主要作用用于继承，改变指向**

```javascript
<script>
    // 改变函数内this指向  js提供了三种方法  call()  apply()  bind()

    // 1. call()
    var o = {
        name: 'andy'
    }

    function fn(a, b) {
        console.log(this);
        console.log(a + b);

    };
    fn.call(o, 1, 2);
    // call 第一个可以调用函数 第二个可以改变函数内的this 指向
    // call 的主要作用可以实现继承
    function Father(uname, age, sex) {
        this.uname = uname;
        this.age = age;
        this.sex = sex;
    }

    function Son(uname, age, sex) {
        Father.call(this, uname, age, sex);
    }
    var son = new Son('刘德华', 18, '男');
    console.log(son);
</script>
```



**apply主要用于数学对象求值**

```javascript
<script>
    // 改变函数内this指向  js提供了三种方法  call()  apply()  bind()

    // 2. apply()  应用 运用的意思
    var o = {
        name: 'andy'
    };

    function fn(arr) {
        console.log(this);
        console.log(arr); // 'pink'

    };
    fn.apply(o, ['pink']);
    // 1. 也是调用函数 第二个可以改变函数内部的this指向
    // 2. 但是他的参数必须是数组(伪数组)
    // 3. apply 的主要应用 比如说我们可以利用 apply 借助于数学内置对象求数组最大值 
    // Math.max();
    var arr = [1, 66, 3, 99, 4];
    var arr1 = ['red', 'pink'];
    // var max = Math.max.apply(null, arr);
    var max = Math.max.apply(Math, arr);
    var min = Math.min.apply(Math, arr);
    console.log(max, min);
</script>
```

**bind()用于不想立即调用，但改变this指向**

**重点方法**

```javascript
<script>
    // 改变函数内this指向  js提供了三种方法  call()  apply()  bind()

    // 3. bind()  绑定 捆绑的意思
    var o = {
        name: 'andy'
    };

    function fn(a, b) {
        console.log(this);
        console.log(a + b);
```


```javascript
    };
    var f = fn.bind(o, 1, 2);
    f();
    // 1. 不会调用原来的函数   可以改变原来函数内部的this 指向
    // 2. 返回的是原函数改变this之后产生的新函数
    // 3. 如果有的函数我们不需要立即调用,但是又想改变这个函数内部的this指向此时用bind
    // 4. 我们有一个按钮,当我们点击了之后,就禁用这个按钮,3秒钟之后开启这个按钮
    // var btn1 = document.querySelector('button');
    // btn1.onclick = function() {
    //     this.disabled = true; // 这个this 指向的是 btn 这个按钮
    //     // var that = this;
    //     setTimeout(function() {
    //         // that.disabled = false; // 定时器函数里面的this 指向的是window
    //         this.disabled = false; // 此时定时器函数里面的this 指向的是btn
    //     }.bind(this), 3000); // 这个this 指向的是btn 这个对象
    // }
    var btns = document.querySelectorAll('button');
    for (var i = 0; i < btns.length; i++) {
        btns[i].onclick = function() {
            this.disabled = true;
            setTimeout(function() {
                this.disabled = false;
            }.bind(this), 2000);
        }
    }
</script>
```

#### call() apply() blind()总结

![image-20220927125250191](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927125250191.png)

### 严格模式

先声明再使用

![image-20220927132559533](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927132559533.png)

![image-20220927190518885](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927190518885.png)

![image-20220927195509617](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927195509617.png)

### 高阶函数

![image-20220927195634914](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927195634914.png)

### 闭包（面试重点）

![image-20220927195902007](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927195902007.png)

#### 什么是闭包

```javascript
<script>
    // 闭包（closure）指有权访问另一个函数作用域中变量的函数。
    // 闭包: 我们fun 这个函数作用域 访问了另外一个函数 fn 里面的局部变量 num
    function fn() {
        var num = 10;

        function fun() {
            console.log(num);

        }
        fun();
    }
    fn();
</script>
```

#### 闭包的作用

```javascript
<script>
    // 闭包（closure）指有权访问另一个函数作用域中变量的函数。
    // 一个作用域可以访问另外一个函数的局部变量 
    // 我们fn 外面的作用域可以访问fn 内部的局部变量
    // 闭包的主要作用: 延伸了变量的作用范围
    function fn() {
        var num = 10;

        // function fun() {
        //     console.log(num);

        // }
        // return fun;
        return function() {
            console.log(num);
        }
    }
    var f = fn();
    f();
    // 类似于
    // var f = function() {
    //         console.log(num);
    //     }
    // var f =  function fun() {
    //         console.log(num);

    //     }
</script>
```

#### 闭包引用-点击li输出当前li的索引号

**直接用循环后使用i作为输出，会因为是异步事件，所以导致i的值不是添加时使用的i**

```javascript
<script>
    // 闭包应用-点击li输出当前li的索引号
    // 1. 我们可以利用动态添加属性的方式
    var lis = document.querySelector('.nav').querySelectorAll('li');
    for (var i = 0; i < lis.length; i++) {
        lis[i].index = i;
        lis[i].onclick = function() {
            // console.log(i);
            console.log(this.index);

        }
    }
    // 2. 利用闭包的方式得到当前小li 的索引号
    for (var i = 0; i < lis.length; i++) {
        // 利用for循环创建了4个立即执行函数
        // 立即执行函数也成为小闭包因为立即执行函数里面的任何一个函数都可以使用它的i这变量
        (function(i) {
            // console.log(i);
            lis[i].onclick = function() {
                console.log(i);

            }
        })(i);
    }
</script>
```

#### 闭包应用-3秒钟之后,打印所有li元素的内容

```javascript
<script>
    // 闭包应用-3秒钟之后,打印所有li元素的内容
    var lis = document.querySelector('.nav').querySelectorAll('li');
    for (var i = 0; i < lis.length; i++) {
        (function(i) {
            setTimeout(function() {
                console.log(lis[i].innerHTML);
            }, 3000)
        })(i);
    }
</script>
```

#### 闭包应用-计算打车价格 

```javascript
<script>
    // 闭包应用-计算打车价格 
    // 打车起步价13(3公里内),  之后每多一公里增加 5块钱.  用户输入公里数就可以计算打车价格
    // 如果有拥堵情况,总价格多收取10块钱拥堵费
    // function fn() {};
    // fn();
    var car = (function() {
        var start = 13; // 起步价  局部变量
        var total = 0; // 总价  局部变量
        return {
            // 正常的总价
            price: function(n) {
                if (n <= 3) {
                    total = start;
                } else {
                    total = start + (n - 3) * 5
                }
                return total;
            },
            // 拥堵之后的费用
            yd: function(flag) {
                return flag ? total + 10 : total;
            }
        }
    })();
    console.log(car.price(5)); // 23
    console.log(car.yd(true)); // 33

    console.log(car.price(1)); // 13
    console.log(car.yd(false)); // 13
</script>
```

### 什么是递归

![image-20220927200742064](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927200742064.png)

```javascript
<script>
    // 递归函数 : 函数内部自己调用自己, 这个函数就是递归函数
    var num = 1;

    function fn() {
        console.log('我要打印6句话');

        if (num == 6) {
            return; // 递归里面必须加退出条件
        }
        num++;
        fn();
    }
    fn();
</script>
```

#### 递归遍历数据和内层数据

```javascript
<script>
    var data = [{
        id: 1,
        name: '家电',
        goods: [{
            id: 11,
            gname: '冰箱',
            goods: [{
                id: 111,
                gname: '海尔'
            }, {
                id: 112,
                gname: '美的'
            }, ]
        }, {
            id: 12,
            gname: '洗衣机'
        }]
    }, {
        id: 2,
        name: '服饰'
    }];
    // 我们想要做输入id号,就可以返回的数据对象
    // 1. 利用 forEach 去遍历里面的每一个对象
    function getID(json, id) {
        var o = {};
        json.forEach(function(item) {
            // console.log(item); // 2个数组元素
            if (item.id == id) {
                // console.log(item);
                o = item;
                // 2. 我们想要得里层的数据 11 12 可以利用递归函数
                // 里面应该有goods这个数组并且数组的长度不为 0 
            } else if (item.goods && item.goods.length > 0) {
                o = getID(item.goods, id);
            }

        });
        return o;
    }
    console.log(getID(data, 1));
    console.log(getID(data, 2));
    console.log(getID(data, 11));
    console.log(getID(data, 12));
    console.log(getID(data, 111));
</script>
```

### 浅拷贝和深拷贝

![image-20220927201255547](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927201255547.png)

**数组和对象都是object的，数组同时是array**

**浅拷贝的对象里面的对象共用同一数据，修改一个也会修改另外一个**

**深拷贝是把每个对象都进行遍历，直到每个数据都是普通类型，就可以直接赋值**

```javascript
<script>
    // 深拷贝拷贝多层, 每一级别的数据都会拷贝.
    var obj = {
        id: 1,
        name: 'andy',
        msg: {
            age: 18
        },
        color: ['pink', 'red']
    };
    var o = {};
    // 封装函数 
    function deepCopy(newobj, oldobj) {
        for (var k in oldobj) {
            // 判断我们的属性值属于那种数据类型
            // 1. 获取属性值  oldobj[k]
            var item = oldobj[k];
            // 2. 判断这个值是否是数组
            if (item instanceof Array) {
                newobj[k] = [];
                deepCopy(newobj[k], item)
            } else if (item instanceof Object) {
                // 3. 判断这个值是否是对象
                newobj[k] = {};
                deepCopy(newobj[k], item)
            } else {
                // 4. 属于简单数据类型
                newobj[k] = item;
            }

        }
    }
    deepCopy(o, obj);
    console.log(o);

    var arr = [];
    console.log(arr instanceof Object);
    o.msg.age = 20;
    console.log(obj);
</script>
```

## ES6

		/*
			let关键字就是用来声明变量的
	
			使用let关键字声明的变量具有块级作用域
	
			在一个大括号中 使用let关键字声明的变量才具有块级作用域 var关键字是不具备这个特点的
	
			防止循环变量变成全局变量
	
			使用let关键字声明的变量没有变量提升
	
			使用let关键字声明的变量具有暂时性死区特性
	
		*/

![image-20220927210920924](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927210920924.png)

**let 会把num进行块内绑定，var num对块内无法影响，产生暂时性死区**

### 经典面试题一

![image-20220927211229989](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927211229989.png)

**因为函数是for循环结束后才调用，调用的i是全局变量，只能输出循环之后得到的i**

### 经典面试题二

![image-20220927211439889](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927211439889.png)

**每次循环都会产生块级作用域，里面的变量i是不一样的，函数调用时会找到这个块级作用域**

### const关键字

**使用const关键字声明的常量具有块级作用域**

**使用const关键字声明的常量必须赋初始值**

**常量声明后值不可更改** (**内存地址不能变，复杂数据类型的数据可以变，但变量不能直接替换，因为会变内存地址**)

```javascript
<script type="text/javascript">
	// 使用const关键字声明的常量具有块级作用域
	// if (true) {
	// 	const a = 10;
	// 	if (true) {
	// 		const a = 20;
	// 		console.log(a);
	// 	}
	// 	console.log(a);
	// }
	// console.log(a);
	
	// 使用const关键字声明的常量必须赋初始值
	// const PI = 3.14;
	
	// 常量声明后值不可更改 
	const PI = 3.14;
	// PI = 100;
	const ary = [100, 200];
	ary[0] = 123;
	ary = [1, 2]
	console.log(ary);
</script>
```

### let、var、const关键字区别

**![image-20220927212258079](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220927212258079.png)**

### 数组解构赋值

**let 定义变量**

```javascript
<script type="text/javascript">
	// 数组解构允许我们按照一一对应的关系从数组中提取值 然后将值赋值给变量
	let ary = [1,2,3];
	let [a, b, c, d, e] = ary;
	console.log(a)
	console.log(b)
	console.log(c)
	console.log(d)
	console.log(e)
</script>
```

### 对象解构赋值

![image-20220928120211609](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928120211609.png)

```javascript
<script type="text/javascript">
	// 对象解构允许我们使用变量的名字匹配对象的属性 匹配成功 将对象属性的值赋值给变量
	
	let person = {name: 'lisi', age: 30, sex: '男'};
	// let { name, age, sex } = person;
	// console.log(name)
	// console.log(age)
	// console.log(sex)
	
	let {name: myName} = person;
	console.log(myName)

</script>
```

### 箭头函数(常用)

#### 箭头函数的定义方法

```javascript
	const fn = () => {
		console.log(123)
	 }
	fn();

```

```javascript
<script type="text/javascript">
	// 箭头函数是用来简化函数定义语法的
	// const fn = () => {
	// 	console.log(123)
	// }
	// fn();
	
	// 在箭头函数中 如果函数体中只有一句代码 并且代码的执行结果就是函数的返回值 函数体大括号可以省略
	// const sum = (n1, n2) => n1 + n2;	 
	// const result = sum(10, 20);
	// console.log(result)
	
	// 在箭头函数中 如果形参只有一个 形参外侧的小括号也是可以省略的
	// const fn = v => {
	// 	alert(v);
	// }
	// fn(20)
	
	
</script>
```

#### 箭头函数的this问题

**箭头函数不绑定this 箭头函数没有自己的this关键字 如果在箭头函数中使用this this关键字将指向箭头函数定义位置中的this**

所以this跟自己定义时候的this的位置是一样的

```javascript
	
	function fn () {
		console.log(this);
		return () => {
			console.log(this)
		}
	}

	const obj = {name: 'zhangsan'};

	const resFn = fn.call(obj);

	resFn();
```

#### 箭头函数面试题

**obj没有函数作用域，所以箭头函数指向的是window对象中的age，如果有作用域就是作用域里面的age**

```javascript
<script type="text/javascript">

	var age = 100;

	var obj = {
		age: 20,
		say: () => {
			alert(this.age)
		}
	}

	obj.say();
</script>
```

### 剩余参数（常用）

![image-20220928121424193](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928121424193.png)

**箭头函数无法使用arguments，所以要使用剩余函数来装剩余数组**

```javascript
<script type="text/javascript">
	// const sum = (...args) => {
	// 	let total = 0;
	// 	args.forEach(item => total += item);
	// 	return total;
	// };

	// console.log(sum(10, 20));
	// console.log(sum(10, 20, 30));
```


```javascript
	let ary1 = ['张三' , '李四', '王五'];
	let [s1, ...s2] = ary1;
	console.log(s1)
	console.log(s2)

</script>
```

#### 剩余参与和结构配合

![image-20220928121517926](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928121517926.png)

**s2剩余参数接受剩余的数值**

### Array扩展运算符（常用）

![image-20220928121649949](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928121649949.png)

#### 合并数组

![image-20220928121728828](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928121728828.png)

#### 将伪数组转换成真正的数组

![image-20220928143303010](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928143303010.png)

#### 构造函数Array.from方法

将类数组或可遍历对象转换为真正的数组

****

```javascript
	var arrayLike = {
		"0": "1",
		"1": "2",
		"length": 2
	}

	var ary = Array.from(arrayLike, item => item * 2)
	console.log(ary)
```

#### find方法

**找出第一个数组成员，有数值和位置**

![image-20220928144006687](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928144006687.png)

#### findIndex方法

**返回索引位置**

![image-20220928144138645](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928144138645.png)

#### includes方法

**返回布尔值，用来判断**

![image-20220928144236358](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928144236358.png)



### string的扩展方法

#### 模板字符串

![image-20220928144423454](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928144423454.png)

#### ![image-20220928144520431](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928144520431.png)

#### 实例方法：startsWith() 和endsWith()

![image-20220928144555089](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928144555089.png)

#### repeat()

![image-20220928144614386](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928144614386.png)

### Set数据结构

**相当于没有重复数值的集合**

![image-20220928144637938](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928144637938.png)

![image-20220928144642135](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220928144642135.png)