# JavaScript 进阶webAPI DOM、BOM 

### 课程安排



![image-20220917110338807](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220917110338807.png)

 ![image-20220917110655925](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220917110655925.png)



# DOM

## Web API基本认知

#### 作用和分类

作用：用js操作html和浏览器

分类：DOM（文档对象模型） BOM（浏览器对象模型）![image-20220917112409979](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220917112409979.png)

DOM 开发网页特效实现用户交互





### 获取DOM对象

![image-20220917221318712](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220917221318712.png)

(**重点**)

1、选择匹配的第一个元素

语法：`			document.querySelector('css选择器')`

参数包含一个或多个有效的css选择器字符串

得到一个对象

![image-20220917222055951](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220917222055951.png)

语法`document.querySelectorAll('css选择器')`     获取标签全部



**思考**

![image-20220917222732234](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220917222732234.png)



**重点**

语法`document.querySelectorAll('css选择器')`得到是伪数组，有序号没有pop()，push()等方法

注意：哪怕只有一个元素，querySelectorAll()获取也是伪数组



#### 其他获取DOM元素方法

![image-20220917223711890](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220917223711890.png)



### 设置和修改DOM内容

`inerText`标签里面的内容  `box.innerText`=`有点意思~`   

注意：不识别标签，里面是字符串

`inerHTML`  可以解析标签

![image-20220918121055588](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918121055588.png)

### 设置和修改DOM属性

![image-20220918152221268](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918152221268.png)





### 设置和改变DOM样式

就是改变css的sty了属性，`box.style.background='pink'`

**注意**：因为没有短横线写法所以background-color不可以，写成小驼峰写法backgroundColor

样式最终呈现写到行内

![image-20220918154454483](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918154454483.png)

### 修改背景图片

修改body可以直接选择body标签所以可以直接些document.body





![image-20220918190935250](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918190935250.png)

**注意**：`box.className='xx'`会覆盖原来的类







![image-20220918191834746](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918191834746.png)

`div.classList.toggle('')` 切换类，有的话就删除，没有就添加，翻转

classList修改不影响原来的类



### 表单属性修改

![image-20220918201256537](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918201256537.png)

disabled   是否不可用

checked 是否勾选



### 定时器函数

`setInterval(函数，间隔时间)`

作用：每隔一段时间调用这个函数

间隔时间单位是毫秒

![image-20220918202112631](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918202112631.png)

show函数不能加（），不然会立刻运行

<!--清除计时器-->

`let timer=setInterval()

timer存储计时器的序号，根据序号清除定时器		

`clearInterval(timer)`

![image-20220918202852241](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918202852241.png)

#### 1.1定时器案例

![image-20220918204515396](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918204515396.png)





#### 1.2使用定时器转换图片案例

**注意：**循环之后的i重新赋值，小心进入循环之后的i++,可以把i=-1

![image-20220918211750239](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918211750239.png)

![image-20220918211730681](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918211730681.png)





## 事件

### 1.1事件监听

 ![image-20220918215105906](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918215105906.png)

**事件是个字符串，纯小写**，事件每次发生，都会执行一次函数

```javascript
btn.addEventListener('click',function(){
				alert('我被点击了')
			})
```

**注意分清标签属性是css还是自带的**

#### 1.1.1随机点名案例

![image-20220918224643740](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918224643740.png)

![image-20220918224857351](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918224857351.png)

**注意timer变量作用域问题**

##### 



### 1.2拓展阅读

![image-20220918233652120](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918233652120.png)







### 1.3事件类型

![image-20220918232230577](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220918232230577.png)

### 1.4微博输入案例

统计文字输入字数

![image-20220919000329804](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919000329804.png)



### 1.5全选反选案例

![image-20220919103247793](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919103247793.png)

![image-20220919103316438](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919103316438.png)

``` javascript
	let all=document.querySelector('#checkAll')
	let cks=document.querySelectorAll('.ck')
	let span=document.querySelector('.all')
	// 全选按钮添加绑定事件
	all.addEventListener('click',function(){
		for (let i=0;i<cks.length;i++)
		{
			cks[i].checked=all.checked
		}
		if(all.checked)
		{
			span.innerHTML='取消'
		}else{
			span.innerHTML='全选'
		}
	})
	// 给小按钮群体绑定事件
	for (let i=0;i<cks.length;i++)
	{
		cks[i].addEventListener('click',function(){
			for (let i=0;i<cks.length;i++)
			{
				// 判定小按钮是否是全部同个状态，是false则return中断
				if (cks[i].checked===false){
					all.checked=false
					return
				}
				
			}
			// 如果没有fasle则可走出循环设置全选按钮的checked状态
			all.checked=true
		})
	}
  </script>
```

### 1.6购物车加减案例

``` <script>
		let num=document.querySelector('#total')
		let add=document.querySelector('#add')
		let reduce=document.querySelector('#reduce')
		if (num.innerHTML==1)
		{
			reduce.disabled=true
		}
		add.addEventListener('click',function(){
			console.log(add);
			num.value++
			reduce.disabled=false
			
		})
		reduce.addEventListener('click',function(){
			num.value--
			if (num.value<=1)
			{
				reduce.disabled=true
			}
		})
		
    </script>
```

**注意：**num.value++和num.value<=1 有隐式转换，value本来是字符串，但被隐式转换成了数值型

### 1.7综合实例tab栏

![image-20220919155731752](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919155731752.png)

```	javascript
		let lis=document.querySelectorAll('.tab .tab-item')
		let divs=document.querySelectorAll('.products .main')
		for(let i=0;i<lis.length;i++)
		{
			lis[i].addEventListener('click',function(){
				// 先删除后复活，排他
				document.querySelector('.tab .active').classList.remove('active')
				this.classList.add('active')
				// 控制div框 小心不要漏类的点和classlist后面不要点
				document.querySelector('.products .active').classList.remove('active')
				divs[i].classList.add('active')
				
			})
		}
	</script>
```

## 节点操作

## 1.1DOM节点

![image-20220919160542162](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919160542162.png)



## 1.2查找节点

#### 1.2.1子节点

![image-20220919163403932](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919163403932.png)

![image-20220919161057859](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919161057859.png)

parentNode是属性，可以叠加找爷爷节点

#### 1.2.2兄弟节点

![image-20220919164403898](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919164403898.png)

#### 1.2.3二维码案例

```	javascript
	let btn=document.querySelector('i')
	btn.addEventListener('click',function(){
		this.parentNode.style.display='none'
	})
```

### 1.3增加节点

![image-20220919164608776](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919164608776.png)

![image-20220919170624883](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919170624883.png)

![image-20220919170205693](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919170205693.png)

#### 1.3.1克隆节点

![image-20220919171718236](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919171718236.png)

#### 1.3.2删除节点

![image-20220919172318914](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919172318914.png)

### 时间对象

#### 1.1时间对象生成

`let date=new Date()`

#### 1.2获取时间方法

![image-20220919174849743](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919174849743.png)

**注意：月份是0~11，星期的0~6，使用时候记得加1**

![image-20220919175441716](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919175441716.png)

![image-20220919175452136](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919175452136.png)

#### 1.3时间戳

`console.log(+new Date());` 获取时间戳方法

![image-20220919184519994](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919184519994.png)





### 综合案例

`textarea.value.trim（）消除字符串前后的空格`



### 重绘和重排(面试会问)

![image-20220919214036608](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919214036608.png)

![image-20220919214207404](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220919214207404.png)

### 案例购物车

获取标签里面的信息：<img src="C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920122739132.png" alt="image-20220920122739132" style="zoom:150%;" />



![image-20220920154507253](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920154507253.png)

```  javascript
 <script>
	  // 获取元素
	let adds=document.querySelectorAll('.add')
	let reduce=document.querySelectorAll('.reduce')
	let inputs=document.querySelectorAll('.count-c input')
	let total=document.querySelectorAll('.total')
	let price=document.querySelectorAll('.price')
	let totalCount=document.querySelector('#totalCount')
	let totalPrice=document.querySelector('#totalPrice')
	let dels=document.querySelectorAll('.del')
	let tbody=document.querySelector('#carBody')
	count()
	for (let i=0;i<adds.length;i++){
		// 给元素绑定事件		
		// +的点击事件
		adds[i].addEventListener('click',function(){
			inputs[i].value++
			reduce[i].disabled=false
			//算出小计价格
			let num=parseInt(price[i].innerHTML)*inputs[i].value
			total[i].innerHTML=num+'¥'		
				count()
		})
		// -的点击事件
		reduce[i].addEventListener('click',function(){
			inputs[i].value--
			// 设置小于1时的减购物车不可用
			if(inputs[i].value<=1){
				reduce[i].disabled=true
			}			
			//算出小计价格
			let num=parseInt(price[i].innerHTML)*inputs[i].value
			total[i].innerHTML=num+'¥'			
		})
		// 删除事件
		dels[i].addEventListener('click',function(){
			// 删除自己爷爷辈来完全删除
			tbody.removeChild(dels[i].parentNode.parentNode)
			count()
		})
	}
	// 算总数函数
	function count(){
		let total=document.querySelectorAll('.total')
		let tprice=0
		let sum=0
		for(let i=0;i<total.length;i++){
			sum=sum+parseInt(inputs[i].value)
			tprice=tprice+parseInt(total[i].innerHTML)
		}
		totalCount.innerHTML=sum
		totalPrice.innerHTML=tprice			
	}

  </script>
```

### 事件对象

#### 1.1获取事件对象

![image-20220920154835983](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920154835983.png)

#### 1.2事件对象常用属性

![image-20220920162344605](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920162344605.png)

#### 1.3移动图片案例

![image-20220920162216345](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920162216345.png)



![image-20220920162204994](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920162204994.png)

**注意:小心单位问题，left后面数字需要加像素px单位**



### 键盘发布微博

读取键盘输入key，使用键盘弹起事件可以免除敲下回车的，调用点击事件

### 事件流

#### 1.1捕获阶段和冒泡

![image-20220920193123245](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920193123245.png)

![image-20220920193431803](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920193431803.png)

![image-20220920195804992](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920195804992.png)

冒泡：在儿子标签单击，会同时触发爸爸、爷爷标签

#### 1.2阻止事件流动

![image-20220920210938959](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920210938959.png)

![image-20220920211008000](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920211008000.png)

#### 1.3阻止事件

![image-20220920212547189](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920212547189.png)

#### 1.4两种注册事件的区别

![image-20220920212746691](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920212746691.png)

#### 1.5事件委托

![image-20220920214257476](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920214257476.png)

![image-20220920214626692](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220920214626692.png)

### 动态创建表格案例

```  javascript
    //  1. 准备好数据后端的数据
    let arr = [
      { stuId: 1001, uname: '欧阳霸天', age: 19, gender: '男', salary: '20000', city: '上海' },
      { stuId: 1002, uname: '令狐霸天', age: 29, gender: '男', salary: '30000', city: '北京' },
      { stuId: 1003, uname: '诸葛霸天', age: 39, gender: '男', salary: '2000', city: '北京' },
    ]
	let add=document.querySelector('.add')
	let tbody=document.querySelector('tbody')
	add.addEventListener('click',function(){
		let uname=document.querySelector('.uname')
		let age=document.querySelector('.age')
		let gender=document.querySelector('.gender')
		let salary=document.querySelector('.salary')
		let city=document.querySelector('.city')
		
		let data={
			stuId: 1000+arr.length+1,
			uname: uname.value,
			age: age.value,
			gender: gender.value, 
			salary: salary.value, 
			city: city.value
		}
		arr.push(data)
		enter()
		uname.value=age.value=salary.value=''
		gender.value='男'
		city.value='北京'
	})
	
	// 删除模块
	tbody.addEventListener('click',function(e){
		// 使用事件对象来判定点击位置
		if(e.target.tagName==='A')
		{
			// 通过给点击的a添加id号来得到数值
			arr.splice(e.target.id,1)
		}
	})
	
	function enter(){		
		//先清空之前的数据
		tbody.innerHTML=''
		for(let i=0;i<arr.length;i++){
			// 获取数据
			
			
			// 创tr标签插入tbody
			let tr=document.createElement('tr')
			tr.innerHTML=`
			<td>${arr[i].stuId}</td>
			<td>${arr[i].uname}</td>
			<td>${arr[i].age}</td>
			<td>${arr[i].gender}</td>
			
			<td>${arr[i].salary}</td>
			<td>${arr[i].city}</td>
			<td>
			  <a href="javascript:" id=${i}>删除</a>
			</td>`
			//用追加会有重复的问题
			tbody.appendChild(tr)
		}
		
	}
	enter()
	// 获取元素
	
	// 填入数据
  </script>
```

### 手风琴效果

![image-20220921142119114](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921142119114.png)

```javascript
  // 获取元素
  let box = document.querySelectorAll('li');// lis = [li, li, li, li, li]
  // 分析：
  // 1、鼠标进入显示图片，
  // 鼠标进入li，让当前li变成800，其他的li变成100
  for (let i = 0; i < box.length; i++) {

    box[i].addEventListener('mouseenter', function () {
      for (let j = 0; j < box.length; j++) {// 事件触发执行，为了让所有li变成240宽的
        box[j].style.width = '100px';
      }
      this.style.width = '800px'
    })

    box[i].addEventListener('mouseleave', function () {
      // 让所有的li变成240
      for (let j = 0; j < box.length; j++) {// 事件触发执行，为了让所有li变成240宽的
        box[j].style.width = '240px';
      }
    })

  }

</script>
```



### 滚动和加载事件

#### 1.1滚动事件

![image-20220921142306996](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921142306996.png)

#### 1.2加载事件

![image-20220921143135225](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921143135225.png)

![image-20220921143510703](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921143510703.png)

![image-20220921143606098](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921143606098.png)

### 元素大小和位置

#### 1.1scroll家族

![image-20220921151606479](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921151606479.png)

![image-20220921151619506](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921151619506.png)



要给body添加高度才有滚动条

#### 1.2offset家族

![image-20220921155407413](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921155407413.png)

![image-20220921155432011](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921155432011.png)

#### 1.3电梯导航案例

```javascript
<script>
	let item=document.querySelectorAll('.aside .item')
	let neirong=document.querySelectorAll('.neirong')
	for(let i=0;i<item.length;i++){
		item[i].addEventListener('click',function(){
			let active=document.querySelector('.aside .active')
			// 清除之前的样式
			active.classList.remove('active')
			// 增加新的样式，排他
			item[i].classList.add('active')
			document.documentElement.scrollTop=neirong[i].offsetTop
			console.log(neirong[i].offsetTop);
			console.log(document.documentElement.scrollTop);
			
		})
	}
```


    </script>

![image-20220921184409985](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921184409985.png)

#### 1.4client家族



![image-20220921185315841](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921185315841.png)

![image-20220921190209210](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921190209210.png)

![image-20220921190307730](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921190307730.png)

### 轮播图案例

![image-20220921211259268](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921211259268.png)

![image-20220921211327218](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921211327218.png)

![image-20220921211335980](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921211335980.png)

```	javascript
	<script>
		let lis=document.querySelectorAll('.indicator li')
		let slides=document.querySelectorAll('.slides li')
		let prev=document.querySelector('.prev')
		let next=document.querySelector('.next')
		let h=document.querySelector('.extra h3')
		let main=document.querySelector('.main')
		function run(i){
			document.querySelector('.indicator .active').classList.remove('active')
			lis[i].classList.add('active')
			
			// 大图跟随小图一起变化
			document.querySelector('.slides .active').classList.remove('active')
			slides[i].classList.add('active')
			
			h.innerHTML=`第${i+1}张图的描述信息`
		}
		for(let i=0;i<lis.length;i++){
			lis[i].addEventListener('mouseenter',function(){
				// 找到active删除，添加新的active
				run(i)
				index=i
			})
		}
		let index=0
		// 点击右按钮和左按钮
		next.addEventListener('click',function(){
			index++
			index=index%lis.length
			run(index)
		})
		
		prev.addEventListener('click',function(){
			index--
			index=(index+lis.length)%lis.length
			run(index)
		})
		
		// 定时器图片自动切换
		let timer=setInterval(function(){
			next.click()
		},1000)
		
		// 鼠标进入停止计时器
		main.addEventListener('mouseenter',function(){
			clearInterval(timer)
		})
		// 鼠标离开启用定时器
		main.addEventListener('mouseleave',function(){
			timer=setInterval(function(){
				next.click()
			},1000)
		})
	</script>

```

![image-20220921213802597](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220921213802597.png)

## BOM浏览器对象

### window对象

### 延迟函数

setTimeout



#### 递归函数

![image-20220922082430115](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922082430115.png)

![image-20220922082803895](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922082803895.png)

### JS执行机制（面试）

![image-20220922084757259](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922084757259.png)

![image-20220922090219141](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922090219141.png)

![image-20220922090444011](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922090444011.png)

### location对象

#### 1.1 location.href

![image-20220922095409216](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922095409216.png)

![image-20220922095341235](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922095341235.png)

#### 1.4 location.hash

![image-20220922093826933](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922093826933.png)

#### 1.5 location.reload

![image-20220922094424512](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922094424512.png)



### histroy对象

![image-20220922094558184](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922094558184.png)

### swiper插件使用

官网https://www.swiper.com.cn/

![image-20220922203958969](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922203958969.png)

![image-20220922203926094](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922203926094.png)

### 本地存储

![image-20220922164444936](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922164444936.png)

![image-20220922164603008](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922164603008.png)

#### 存储简单数据类型

![image-20220922162911913](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922162911913.png)

#### 存储复杂数据类型

复杂数据类型要转换成json数据类型来存取

![image-20220922163913799](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922163913799.png)

![image-20220922164424436](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922164424436.png)

### 自定义属性

![image-20220922175358954](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922175358954.png)

### 综合案例-学生信息表

![image-20220922204404731](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220922204404731.png)

### 正则表达式

![image-20220923103446406](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923103446406.png)

![image-20220923103740638](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923103740638.png)

![image-20220923104105173](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923104105173.png)

![image-20220923104245158](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923104245158.png)

![image-20220923104818356](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923104818356.png)

![image-20220923104830107](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923104830107.png)

#### 元字符

![image-20220923105417212](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923105417212.png)

![image-20220923105501694](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923105501694.png)

![image-20220923105655693](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923105655693.png)

![image-20220923110214688](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923110214688.png)

#### 元字符

![image-20220923145012088](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923145012088.png)

![image-20220923145058528](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923145058528.png)

![image-20220923150806128](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923150806128.png)

#### 用户名案例

![image-20220923150833354](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923150833354.png)

![image-20220923150937487](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923150937487.png)

![image-20220923151012961](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923151012961.png)

![image-20220923151046390](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923151046390.png)

![image-20220923171126070](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923171126070.png)

![image-20220923171803043](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923171803043.png)

### 注册模块案例

```  javascript
  <script>
	  // 获取元素
	let code=document.querySelector('.code')
	let icode=document.querySelector('[name=code]')
	let username=document.querySelector('[name=username]')
	let phone=document.querySelector('[name=phone]')
	let pass=document.querySelector('[name=password]')
	let confirm=document.querySelector('[name=confirm]')
	let icon=document.querySelector('.iconfont')
	let submit=document.querySelector('.submit')
	let form=document.querySelector('.xtx-form')
	
	// 验证码获取
	code.addEventListener('click',function(){
		let num=5
		code.innerHTML='05秒可重新获取'
		let timer=setInterval(function(){
			num--
			code.innerHTML=`0${num}秒可重新获取`
			if(num===0){
				code.innerHTML=`重新获取`
				clearInterval(timer)
				return
			}
		},1000)
	})
	// 用户昵称添加事件
	username.addEventListener('change',verifyUsername)
	function verifyUsername(){
		// 错误反馈
		let msg=username.nextElementSibling
		let reg=/^[a-zA-Z0-9-_]{6,10}$/
		if(!reg.test(username.value)==true){
			msg.innerHTML='请输入6-10位字符'
			return false
		}
		msg.innerHTML=''
		return true
	}
	// 手机号验证
	phone.addEventListener('change',verifyPhone)
	function verifyPhone(){
		// 错误反馈
		let msg=phone.nextElementSibling
		let reg=/^1(3\d|4[5-9]|5[0-35-9]|6[567]|7[0-8]|8\d|9[0-35-9])\d{8}$/
		if(!reg.test(phone.value)===true){
			msg.innerHTML='请输入11位正确电话号码'
			return false
		}
		msg.innerHTML=''
		return true
	}
	
	// 验证码验证
	icode.addEventListener('change',verifyCode)
	function verifyCode(){
		// 错误反馈
		let msg=icode.nextElementSibling
		let reg=/^\d{6}$/
		if(!reg.test(icode.value)===true){
			msg.innerHTML='请输入6位数字'
			return false
		}
		msg.innerHTML=''
		return true
	}
	pass.addEventListener('change',verifyPass)
	function verifyPass(){
		// 错误反馈
		let msg=pass.nextElementSibling
		let reg=/^[a-zA-Z0-9-_]{6,20}$/
		if(!reg.test(pass.value)===true){
			msg.innerHTML='请输入合法密码'
			return false
		}
		msg.innerHTML=''
		return true
	}
	
	confirm.addEventListener('change',verifyConfirm)
	function verifyConfirm(){
		// 错误反馈
		let msg=confirm.nextElementSibling
		let reg=/^[a-zA-Z0-9-_]{6,20}$/
		if(confirm.value!==pass.value){
			msg.innerHTML='与密码不相同'
			return false
		}
		msg.innerHTML=''
		return true
	}
	icon.addEventListener('click',function(){
		icon.classList.toggle('icon-queren2')
	})
	
	submit.addEventListener('click',function(){
		if(!verifyUsername())
		{
			form.preventDefault()
		}
		if(!verifyCode())
		{
			form.preventDefault()
		}
		if(!verifyConfirm())
		{
			form.preventDefault()
		}
		if(!verifyPass())
		{
			form.preventDefault()
		}
		if(!verifyPhone())
		{
			form.preventDefault()
		}
	})
	
  </script>

```

#### change事件

![image-20220923174242893](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923174242893.png)

![image-20220923191447097](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923191447097.png)

**注意:toggle是反转函数,没有就加,有就取消**

![image-20220923194512897](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220923194512897.png)

禁止表单提交