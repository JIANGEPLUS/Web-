### Math数学对象

![image-20220916225050369](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220916225050369.png)

蓝色的是属性，紫色的是方法

`Math.random()` 0到1的随机数，可取0不能1

`Math.celi()`向上取整 ,1,9取2，返回的是整数

`Math.round()`就近取整（负数往大取整），例如1.1取1，1.5取2，-1.5取-1，-1.5为特殊

![image-20220916230110901](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220916230110901.png)

求N-M之间的一个随机数格式

`Math.random()*(m-n+1)`+n



#### 







#### 不同数据类型的存储方式

简单数组类型又称值类型，复杂数据类型又称引用类型

分别存于堆和栈

![image-20220917105048378](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220917105048378.png)

**简单数据类型存于栈，复杂数据类型把堆里面的地址放在栈，通过栈上的地址去找堆的数据**





```let num1=10 ```

```let num2=num1 ```

```num2=20```  赋值不影响num1本身，因为简单数据类型存储的是值，把num1的值赋值num2



对象 属于引用数据类型 栈里面存储的是地址

![image-20220917110000095](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220917110000095.png)

```let obj1={} ```

```let obj2=obj1``` 指向同一个地址，通过栈中的地址找堆中数据





