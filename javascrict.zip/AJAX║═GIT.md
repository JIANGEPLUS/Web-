# AJAX和GIT

## HTTP协议

### HTTP请求消息

#### 请求方式

#### 请求头

![image-20220929175358365](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220929175358365.png)

### 请求体



![image-20220929175300759](C:\Users\JIAN\AppData\Roaming\Typora\typora-user-images\image-20220929175300759.png)